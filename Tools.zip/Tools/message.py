# -*- coding: utf-8 -*-
# 作者:someonezlhao@outlook.com
# 时间:2025/3/1 20:56
# 备注:大部分代码来自Marscode AI
#
# 本程序是自由软件：您可以根据自由软件基金会发布的GNU通用公共许可证的条款重新分发和/或修改它，版本3或（根据您的选择）任何更高版本。
#
# 本程序是希望它有用，但没有任何担保；甚至没有适销性或特定用途适用性的隐含担保。有关更多详细信息，请参阅GNU通用公共许可证。
#
# 您应该已经收到GNU通用公共许可证的副本。如果没有，请参阅<http://www.gnu.org/licenses/>。
import os
import platform
import tkinter as tk
from tkinter import messagebox
from tkinter import ttk
from PIL import Image, ImageTk
import psutil  # type: ignore
import threading
import cpuinfo   # type: ignore
import wmi # type: ignore # 新增
import time

# 获取当前文件所在目录
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ASSETS_DIR = os.path.join(BASE_DIR, "Assets")

# 定义语言字典
LANGUAGES = {
    'zh': {
        'title': '信息',
        'system_tab': '系统信息',
        'cpu_tab': 'CPU 信息',
        'memory_disk_tab': '内存和硬盘',
        'network_tab': '网络信息',
        'motherboard_tab': '主板信息',
        'os': '操作系统: ',
        'network_name': '网络名称: ',
        'system_install_date': '系统安装日期: ',
        'system_manufacturer': '系统制造商: ',
        'system_model': '系统型号: ',
        'system_architecture': '系统位数: ',
        'system_language': '系统语言: ',
        'cpu_model': 'CPU 型号: ',
        'cpu_count': 'CPU 核心数: ',
        'cpu_freq': 'CPU 频率: ',
        'cpu_total_usage': 'CPU 总体使用率: ',
        'cpu_core_usage': '核心 ',
        'memory': '内存: ',
        'disk': '硬盘: ',
        'network': '网络:\n',
        'motherboard_manufacturer': '主板制造商: ',
        'motherboard_product': '主板型号: ',
        'motherboard_version': '主板版本: ',
        'motherboard_serial_number': '主板序列号: ',
        'bios_version': 'BIOS 版本: ',
        'bios_release_date': 'BIOS 发布日期: ',
        'bios_manufacturer': 'BIOS 制造商: ',
        'bus_speed': '总线速度: ',
        'part_number': '部件编号: ',
        'sku': 'SKU: ',
        'weight': '重量: ',
        'slot_info': '主板插槽信息:\n',
        'chipset': '主板芯片组信息: ',
        'close_confirm': '你确定要关闭吗？',
        'language_button': '切换到英文',
        'splash_text': '正在加载...',
        'cpu_vendor': 'CPU 厂商: ',
        'cpu_family': 'CPU 系列: ',
        'cpu_stepping': 'CPU 步进: ',
        'cpu_features': '支持指令集: ',
        'cpu_cache': 'CPU 缓存: '
    },
    'en': {
        'title': 'Message',
        'system_tab': 'System Information',
        'cpu_tab': 'CPU Information',
        'memory_disk_tab': 'Memory and Disk',
        'network_tab': 'Network Information',
        'motherboard_tab': 'Motherboard Information',
        'os': 'OS: ',
        'network_name': 'Network Name: ',
        'system_install_date': 'System Install Date: ',
        'system_manufacturer': 'System Manufacturer: ',
        'system_model': 'System Model: ',
        'system_architecture': 'System Architecture: ',
        'system_language': 'System Language: ',
        'cpu_model': 'CPU Model: ',
        'cpu_count': 'CPU Cores: ',
        'cpu_freq': 'CPU Frequency: ',
        'cpu_total_usage': 'Total CPU Usage: ',
        'cpu_core_usage': 'Core ',
        'memory': 'Memory: ',
        'disk': 'Disk: ',
        'network': 'Network:\n',
        'motherboard_manufacturer': 'Motherboard Manufacturer: ',
        'motherboard_product': 'Motherboard Model: ',
        'motherboard_version': 'Motherboard Version: ',
        'motherboard_serial_number': 'Motherboard Serial Number: ',
        'bios_version': 'BIOS Version: ',
        'bios_release_date': 'BIOS Release Date: ',
        'bios_manufacturer': 'BIOS Manufacturer: ',
        'bus_speed': 'Bus Speed: ',
        'part_number': 'Part Number: ',
        'sku': 'SKU: ',
        'weight': 'Weight: ',
        'slot_info': 'Motherboard Slot Information:\n',
        'chipset': 'Motherboard Chipset Information: ',
        'close_confirm': 'Are you really want to close?',
        'language_button': 'Switch to Chinese',
        'splash_text': 'Loading...',
        'cpu_vendor': 'CPU Vendor: ',
        'cpu_family': 'CPU Family: ',
        'cpu_stepping': 'CPU Stepping: ',
        'cpu_features': 'Supported Features: ',
        'cpu_cache': 'CPU Cache: '
    }
}

# 默认语言设置
current_language = 'zh'

# 创建启动动画窗口
splash = tk.Tk()
splash.overrideredirect(True)  # 去除窗口边框
splash.geometry("300x200+{}+{}".format(splash.winfo_screenwidth() // 2 - 150, splash.winfo_screenheight() // 2 - 100))

# 启动
splash_image = Image.open(os.path.join(ASSETS_DIR, "splash.png"))

# 获取图片原始宽高
original_width, original_height = splash_image.size
# 窗口宽高
window_width = 300
window_height = 200

# 计算宽高比
width_ratio = window_width / original_width
height_ratio = window_height / original_height

# 选择较小的比例，确保图片能完整显示在窗口内
if width_ratio < height_ratio:
    new_width = window_width
    new_height = int(original_height * width_ratio)
else:
    new_height = window_height
    new_width = int(original_width * height_ratio)

# 按比例调整图片大小
splash_image = splash_image.resize((new_width, new_height), Image.LANCZOS)
splash_photo = ImageTk.PhotoImage(splash_image)

# 创建一个 Canvas 并将图片作为背景
canvas = tk.Canvas(splash, width=window_width, height=window_height)
canvas.pack()
# 计算图片居中的位置
x = (window_width - new_width) // 2
y = (window_height - new_height) // 2
canvas.create_image(x, y, anchor=tk.NW, image=splash_photo)

# 显示加载文本
splash_text = tk.Label(splash, text=LANGUAGES[current_language]['splash_text'], font=("Arial", 12), bg='white')
# 将文本放置在 Canvas 上
canvas.create_window(150, 170, window=splash_text)

splash.update()  # 更新启动动画窗口

root = tk.Tk()
root.title(LANGUAGES[current_language]['title'])

# 图标
try:
    root.iconbitmap(os.path.join(ASSETS_DIR, "Mtools.ico"))
except Exception as e:
    print(f"加载图标图像时出错: {e}")

window_width = 400
window_height = 800

screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()

x = (screen_width - window_width) // 2
y = (screen_height - window_height) // 2

root.geometry(f"{window_width}x{window_height}+{x}+{y}")

os_name = platform.system()
os_version = platform.version()
computer_name = platform.node()
cpu_count = psutil.cpu_count(logical=False)
# 获取 CPU 型号
cpu_info = cpuinfo.get_cpu_info()
cpu_model = cpu_info['brand_raw']
# 获取 CPU 频率
cpu_freq = psutil.cpu_freq()

def get_network_info():
    network_info = psutil.net_io_counters(pernic=True)
    result = ""
    for interface, stats in network_info.items():
        result += f"接口: {interface}\n"
        result += f"  发送字节数: {stats.bytes_sent}\n"
        result += f"  接收字节数: {stats.bytes_recv}\n"
    return result

memory = psutil.virtual_memory()
total_memory = memory.total / (1024 ** 3)
available_memory = memory.available / (1024 ** 3)
disk = psutil.disk_usage('/')
total_disk = disk.total / (1024 ** 3)  # 转换为GB
used_disk = disk.used / (1024 ** 3)  # 转换为GB
free_disk = disk.free / (1024 ** 3)  # 转换为GB

# 创建 Notebook 组件
notebook = ttk.Notebook(root)
notebook.pack(fill=tk.BOTH, expand=True)

# 系统信息选项卡
system_tab = ttk.Frame(notebook)
notebook.add(system_tab, text=LANGUAGES[current_language]['system_tab'])

# OS 信息
os_label = tk.Label(system_tab, text=LANGUAGES[current_language]['os'] + os_name + ' ' + os_version)
os_label.grid(row=0, column=0, sticky=tk.W, padx=10, pady=5)
# 网络名称
network_name_label = tk.Label(system_tab, text=LANGUAGES[current_language]['network_name'] + computer_name)
network_name_label.grid(row=1, column=0, sticky=tk.W, padx=10, pady=5)

# 获取更多系统信息
c = wmi.WMI()
# 获取系统安装日期
system_install_date = c.Win32_OperatingSystem()[0].InstallDate
# 获取系统制造商
system_manufacturer = c.Win32_ComputerSystem()[0].Manufacturer
# 获取系统型号
system_model = c.Win32_ComputerSystem()[0].Model
# 获取系统位数
system_architecture = platform.architecture()[0]
# 获取系统语言
system_language = c.Win32_OperatingSystem()[0].OSLanguage

# 显示更多系统信息
system_install_date_label = tk.Label(system_tab, text=LANGUAGES[current_language]['system_install_date'] + system_install_date)
system_install_date_label.grid(row=2, column=0, sticky=tk.W, padx=10, pady=5)
system_manufacturer_label = tk.Label(system_tab, text=LANGUAGES[current_language]['system_manufacturer'] + system_manufacturer)
system_manufacturer_label.grid(row=3, column=0, sticky=tk.W, padx=10, pady=5)
system_model_label = tk.Label(system_tab, text=LANGUAGES[current_language]['system_model'] + system_model)
system_model_label.grid(row=4, column=0, sticky=tk.W, padx=10, pady=5)
system_architecture_label = tk.Label(system_tab, text=LANGUAGES[current_language]['system_architecture'] + system_architecture)
system_architecture_label.grid(row=5, column=0, sticky=tk.W, padx=10, pady=5)
system_language_label = tk.Label(system_tab, text=LANGUAGES[current_language]['system_language'] + str(system_language))
system_language_label.grid(row=6, column=0, sticky=tk.W, padx=10, pady=5)

## CPU 信息选项卡
cpu_tab = ttk.Frame(notebook)
notebook.add(cpu_tab, text=LANGUAGES[current_language]['cpu_tab'])

# CPU 型号
cpu_model_label = tk.Label(cpu_tab, text=LANGUAGES[current_language]['cpu_model'] + cpu_model)
cpu_model_label.grid(row=0, column=0, sticky=tk.W, padx=10, pady=5)

# 获取更多CPU信息
cpu_info = cpuinfo.get_cpu_info()
cpu_family = cpu_info.get('family', '未知')
cpu_stepping = cpu_info.get('stepping', '未知')
cpu_vendor_id = cpu_info.get('vendor_id_raw', '未知')
cpu_features = ', '.join(cpu_info.get('flags', ['未知']))
cpu_l1_cache = cpu_info.get('l1_data_cache_size', '未知')
cpu_l2_cache = cpu_info.get('l2_cache_size', '未知')
cpu_l3_cache = cpu_info.get('l3_cache_size', '未知')

# 显示更多CPU信息
cpu_vendor_label = tk.Label(cpu_tab, text=f"CPU 厂商: {cpu_vendor_id}")
cpu_vendor_label.grid(row=1, column=0, sticky=tk.W, padx=10, pady=5)

cpu_family_label = tk.Label(cpu_tab, text=f"CPU 系列: {cpu_family}")
cpu_family_label.grid(row=2, column=0, sticky=tk.W, padx=10, pady=5)

cpu_stepping_label = tk.Label(cpu_tab, text=f"CPU 步进: {cpu_stepping}")
cpu_stepping_label.grid(row=3, column=0, sticky=tk.W, padx=10, pady=5)

cpu_features_label = tk.Label(cpu_tab, text=f"支持指令集: {cpu_features}")
cpu_features_label.grid(row=4, column=0, sticky=tk.W, padx=10, pady=5)

cpu_cache_label = tk.Label(cpu_tab, text=f"CPU 缓存: L1: {cpu_l1_cache}, L2: {cpu_l2_cache}, L3: {cpu_l3_cache}")
cpu_cache_label.grid(row=5, column=0, sticky=tk.W, padx=10, pady=5)

# CPU 核心数
cpu_count_label = tk.Label(cpu_tab, text=LANGUAGES[current_language]['cpu_count'] + str(cpu_count))
cpu_count_label.grid(row=6, column=0, sticky=tk.W, padx=10, pady=5)

# CPU 频率
cpu_freq_label = tk.Label(cpu_tab, text=LANGUAGES[current_language]['cpu_freq'] + f"{cpu_freq.current:.2f} MHz (最大: {cpu_freq.max:.2f} MHz)")
cpu_freq_label.grid(row=7, column=0, sticky=tk.W, padx=10, pady=5)

# 创建一个可变的字符串对象，用于显示总体 CPU 使用率
cpu_label_text = tk.StringVar()
cpu_label_text.set(LANGUAGES[current_language]['cpu_total_usage'] + f"{psutil.cpu_percent(interval=1)}%")
cpu_total_usage_label = tk.Label(cpu_tab, textvariable=cpu_label_text)
cpu_total_usage_label.grid(row=3, column=0, sticky=tk.W, padx=10, pady=5)

# 创建一个可变的字符串对象，用于显示每个核心的 CPU 使用率
core_text_vars = []
core_usage_labels = []
for i in range(cpu_count):
    var = tk.StringVar()
    var.set(LANGUAGES[current_language]['cpu_core_usage'] + f"{i} 使用率: {psutil.cpu_percent(percpu=True)[i]}%")
    label = tk.Label(cpu_tab, textvariable=var)
    label.grid(row=4 + i, column=0, sticky=tk.W, padx=10, pady=5)
    core_text_vars.append(var)
    core_usage_labels.append(label)

# 内存和硬盘信息选项卡
memory_disk_tab = ttk.Frame(notebook)
notebook.add(memory_disk_tab, text=LANGUAGES[current_language]['memory_disk_tab'])

# 内存信息
memory_label = tk.Label(memory_disk_tab, text=LANGUAGES[current_language]['memory'] + '≈' + str(round(total_memory, 2)) + 'G')
memory_label.grid(row=0, column=0, sticky=tk.W, padx=10, pady=5)

# 添加详细内存信息
memory_used = tk.Label(memory_disk_tab, text=f"{LANGUAGES[current_language]['memory']}已用: {round(memory.used / (1024 ** 3), 2)}G")
memory_used.grid(row=1, column=0, sticky=tk.W, padx=10, pady=5)

memory_available = tk.Label(memory_disk_tab, text=f"{LANGUAGES[current_language]['memory']}可用: {round(memory.available / (1024 ** 3), 2)}G")
memory_available.grid(row=2, column=0, sticky=tk.W, padx=10, pady=5)

memory_percent = tk.Label(memory_disk_tab, text=f"{LANGUAGES[current_language]['memory']}使用率: {memory.percent}%")
memory_percent.grid(row=3, column=0, sticky=tk.W, padx=10, pady=5)

# 硬盘信息
disk_label = tk.Label(memory_disk_tab, text=LANGUAGES[current_language]['disk'] + '≈' + str(round(total_disk, 2)) + 'G')
disk_label.grid(row=4, column=0, sticky=tk.W, padx=10, pady=5)

# 添加详细硬盘信息
disk_used = tk.Label(memory_disk_tab, text=f"{LANGUAGES[current_language]['disk']}已用: {round(used_disk, 2)}G")
disk_used.grid(row=5, column=0, sticky=tk.W, padx=10, pady=5)

disk_free = tk.Label(memory_disk_tab, text=f"{LANGUAGES[current_language]['disk']}可用: {round(free_disk, 2)}G")
disk_free.grid(row=6, column=0, sticky=tk.W, padx=10, pady=5)

disk_percent = tk.Label(memory_disk_tab, text=f"{LANGUAGES[current_language]['disk']}使用率: {disk.percent}%")
disk_percent.grid(row=7, column=0, sticky=tk.W, padx=10, pady=5)

# 添加交换分区信息
swap = psutil.swap_memory()
swap_total = tk.Label(memory_disk_tab, text=f"交换分区总量: {round(swap.total / (1024 ** 3), 2)}G")
swap_total.grid(row=8, column=0, sticky=tk.W, padx=10, pady=5)

swap_used = tk.Label(memory_disk_tab, text=f"交换分区已用: {round(swap.used / (1024 ** 3), 2)}G")
swap_used.grid(row=9, column=0, sticky=tk.W, padx=10, pady=5)

swap_free = tk.Label(memory_disk_tab, text=f"交换分区可用: {round(swap.free / (1024 ** 3), 2)}G")
swap_free.grid(row=10, column=0, sticky=tk.W, padx=10, pady=5)

swap_percent = tk.Label(memory_disk_tab, text=f"交换分区使用率: {swap.percent}%")
swap_percent.grid(row=11, column=0, sticky=tk.W, padx=10, pady=5)

# 网络信息选项卡
network_tab = ttk.Frame(notebook)
notebook.add(network_tab, text=LANGUAGES[current_language]['network_tab'])

# 网络信息
network_label = tk.Label(network_tab, text=LANGUAGES[current_language]['network'] + get_network_info())
network_label.grid(row=0, column=0, sticky=tk.W, padx=10, pady=5)

# 主板信息选项卡
motherboard_tab = ttk.Frame(notebook)
notebook.add(motherboard_tab, text=LANGUAGES[current_language]['motherboard_tab'])

# 获取主板信息
c = wmi.WMI()
motherboard = c.Win32_BaseBoard()[0]
manufacturer = motherboard.Manufacturer
product = motherboard.Product
version = motherboard.Version
serial_number = motherboard.SerialNumber
bios = c.Win32_BIOS()[0]
bios_version = bios.SMBIOSBIOSVersion
bios_release_date = bios.ReleaseDate
bios_manufacturer = bios.Manufacturer
# 检查 BusSpeed 属性是否存在
if hasattr(motherboard, 'BusSpeed'):
    bus_speed = motherboard.BusSpeed
else:
    bus_speed = "未获取到"
part_number = motherboard.PartNumber
sku = motherboard.SKU
# 检查 Weight 属性是否存在
if hasattr(motherboard, 'Weight'):
    weight = motherboard.Weight
else:
    weight = "未获取到"

# 获取主板插槽信息
try:
    slots = c.Win32_PCIDevice()
    slot_info = ""
    for slot in slots:
        slot_info += f"插槽名称: {slot.Name}, 设备 ID: {slot.DeviceID}\n"
except Exception as e:
    slot_info = f"获取主板插槽信息失败: {str(e)}"

# 获取主板芯片组信息
try:
    chipset = c.Win32_SystemEnclosure()[0].SMBIOSAssetTag if c.Win32_SystemEnclosure() else "未获取到"
except Exception as e:
    chipset = f"获取主板芯片组信息失败: {str(e)}"

# 显示主板信息
motherboard_manufacturer_label = tk.Label(motherboard_tab, text=LANGUAGES[current_language]['motherboard_manufacturer'] + manufacturer)
motherboard_manufacturer_label.grid(row=0, column=0, sticky=tk.W, padx=10, pady=5)
motherboard_product_label = tk.Label(motherboard_tab, text=LANGUAGES[current_language]['motherboard_product'] + product)
motherboard_product_label.grid(row=1, column=0, sticky=tk.W, padx=10, pady=5)
motherboard_version_label = tk.Label(motherboard_tab, text=LANGUAGES[current_language]['motherboard_version'] + version)
motherboard_version_label.grid(row=2, column=0, sticky=tk.W, padx=10, pady=5)
motherboard_serial_number_label = tk.Label(motherboard_tab, text=LANGUAGES[current_language]['motherboard_serial_number'] + serial_number)
motherboard_serial_number_label.grid(row=3, column=0, sticky=tk.W, padx=10, pady=5)
bios_version_label = tk.Label(motherboard_tab, text=LANGUAGES[current_language]['bios_version'] + bios_version)
bios_version_label.grid(row=4, column=0, sticky=tk.W, padx=10, pady=5)
bios_release_date_label = tk.Label(motherboard_tab, text=LANGUAGES[current_language]['bios_release_date'] + bios_release_date)
bios_release_date_label.grid(row=5, column=0, sticky=tk.W, padx=10, pady=5)
bios_manufacturer_label = tk.Label(motherboard_tab, text=LANGUAGES[current_language]['bios_manufacturer'] + bios_manufacturer)
bios_manufacturer_label.grid(row=6, column=0, sticky=tk.W, padx=10, pady=5)
bus_speed_label = tk.Label(motherboard_tab, text=LANGUAGES[current_language]['bus_speed'] + f"{bus_speed} MHz")
bus_speed_label.grid(row=7, column=0, sticky=tk.W, padx=10, pady=5)
part_number = part_number if part_number is not None else "未获取到"
part_number_label = tk.Label(motherboard_tab, text=LANGUAGES[current_language]['part_number'] + part_number)
part_number_label.grid(row=8, column=0, sticky=tk.W, padx=10, pady=5)
sku = sku if sku is not None else "未获取到"
sku_label = tk.Label(motherboard_tab, text=LANGUAGES[current_language]['sku'] + sku)
sku_label.grid(row=9, column=0, sticky=tk.W, padx=10, pady=5)
weight_label = tk.Label(motherboard_tab, text=LANGUAGES[current_language]['weight'] + str(weight))
weight_label.grid(row=10, column=0, sticky=tk.W, padx=10, pady=5)
slot_info_label = tk.Label(motherboard_tab, text=LANGUAGES[current_language]['slot_info'] + slot_info)
slot_info_label.grid(row=11, column=0, sticky=tk.W, padx=10, pady=5)
chipset_label = tk.Label(motherboard_tab, text=LANGUAGES[current_language]['chipset'] + chipset)
chipset_label.grid(row=12, column=0, sticky=tk.W, padx=10, pady=5)

# 在创建 Label 时添加 wraplength 参数
cpu_features_label = tk.Label(cpu_tab, text=f"支持指令集: {cpu_features}", wraplength=350)
cpu_features_label.grid(row=4, column=0, sticky=tk.W, padx=10, pady=5)

# 对于其他需要换行的 Label 也添加 wraplength 参数
network_label = tk.Label(network_tab, text=LANGUAGES[current_language]['network'] + get_network_info(), wraplength=350)
network_label.grid(row=0, column=0, sticky=tk.W, padx=10, pady=5)

slot_info_label = tk.Label(motherboard_tab, text=LANGUAGES[current_language]['slot_info'] + slot_info, wraplength=350)
slot_info_label.grid(row=11, column=0, sticky=tk.W, padx=10, pady=5)

# 语言切换按钮
def switch_language():
    global current_language
    if current_language == 'zh':
        current_language = 'en'
    else:
        current_language = 'zh'

    # 更新窗口标题
    root.title(LANGUAGES[current_language]['title'])

    # 更新选项卡文本
    notebook.tab(system_tab, text=LANGUAGES[current_language]['system_tab'])
    notebook.tab(cpu_tab, text=LANGUAGES[current_language]['cpu_tab'])
    notebook.tab(memory_disk_tab, text=LANGUAGES[current_language]['memory_disk_tab'])
    notebook.tab(network_tab, text=LANGUAGES[current_language]['network_tab'])
    notebook.tab(motherboard_tab, text=LANGUAGES[current_language]['motherboard_tab'])

    # 更新系统信息选项卡文本
    os_label.config(text=LANGUAGES[current_language]['os'] + os_name + ' ' + os_version)
    network_name_label.config(text=LANGUAGES[current_language]['network_name'] + computer_name)
    system_install_date_label.config(text=LANGUAGES[current_language]['system_install_date'] + system_install_date)
    system_manufacturer_label.config(text=LANGUAGES[current_language]['system_manufacturer'] + system_manufacturer)
    system_model_label.config(text=LANGUAGES[current_language]['system_model'] + system_model)
    system_architecture_label.config(text=LANGUAGES[current_language]['system_architecture'] + system_architecture)
    system_language_label.config(text=LANGUAGES[current_language]['system_language'] + str(system_language))

    # 更新CPU信息选项卡文本
    cpu_model_label.config(text=LANGUAGES[current_language]['cpu_model'] + cpu_model)
    cpu_count_label.config(text=LANGUAGES[current_language]['cpu_count'] + str(cpu_count))
    cpu_freq_label.config(text=LANGUAGES[current_language]['cpu_freq'] + f"{cpu_freq.current:.2f} MHz (最大: {cpu_freq.max:.2f} MHz)" if current_language == 'zh' else f"{cpu_freq.current:.2f} MHz (Max: {cpu_freq.max:.2f} MHz)")
    cpu_label_text.set(LANGUAGES[current_language]['cpu_total_usage'] + f"{psutil.cpu_percent(interval=1)}%")
    for i in range(cpu_count):
        core_text_vars[i].set(LANGUAGES[current_language]['cpu_core_usage'] + f"{i} 使用率: {psutil.cpu_percent(percpu=True)[i]}%" if current_language == 'zh' else f"Core {i} Usage: {psutil.cpu_percent(percpu=True)[i]}%")

    # 更新内存和硬盘信息选项卡文本
    memory_label.config(text=LANGUAGES[current_language]['memory'] + '≈' + str(round(total_memory, 2)) + 'G' if current_language == 'zh' else LANGUAGES[current_language]['memory'] + f"≈ {round(total_memory, 2)} GB")
    disk_label.config(text=LANGUAGES[current_language]['disk'] + '≈' + str(round(total_disk, 2)) + 'G' if current_language == 'zh' else LANGUAGES[current_language]['disk'] + f"≈ {round(total_disk, 2)} GB")
    
    # 更新网络信息选项卡文本
    network_info = get_network_info()
    if current_language == 'zh':
        network_info = network_info.replace("接口:", "Interface:").replace("发送字节数:", "Sent Bytes:").replace("接收字节数:", "Received Bytes:")
    network_label.config(text=LANGUAGES[current_language]['network'] + network_info)

    # 更新主板信息选项卡文本
    motherboard_manufacturer_label.config(text=LANGUAGES[current_language]['motherboard_manufacturer'] + manufacturer)
    motherboard_product_label.config(text=LANGUAGES[current_language]['motherboard_product'] + product)
    motherboard_version_label.config(text=LANGUAGES[current_language]['motherboard_version'] + version)
    motherboard_serial_number_label.config(text=LANGUAGES[current_language]['motherboard_serial_number'] + serial_number)
    bios_version_label.config(text=LANGUAGES[current_language]['bios_version'] + bios_version)
    bios_release_date_label.config(text=LANGUAGES[current_language]['bios_release_date'] + bios_release_date)
    bios_manufacturer_label.config(text=LANGUAGES[current_language]['bios_manufacturer'] + bios_manufacturer)
    bus_speed_label.config(text=LANGUAGES[current_language]['bus_speed'] + f"{bus_speed} MHz")
    part_number_label.config(text=LANGUAGES[current_language]['part_number'] + part_number)
    sku_label.config(text=LANGUAGES[current_language]['sku'] + sku)
    weight_label.config(text=LANGUAGES[current_language]['weight'] + str(weight))

    # 重新获取 slot_info
    try:
        c = wmi.WMI()
        slots = c.Win32_PCIDevice()
        slot_info = ""
        for slot in slots:
            slot_info += f"插槽名称: {slot.Name}, 设备 ID: {slot.DeviceID}\n"
    except Exception as e:
        slot_info = f"获取主板插槽信息失败: {str(e)}"

    slot_info = slot_info.replace("插槽名称:", "Slot Name:").replace("设备 ID:", "Device ID:") if current_language == 'en' else slot_info
    slot_info_label.config(text=LANGUAGES[current_language]['slot_info'] + slot_info)
    chipset_label.config(text=LANGUAGES[current_language]['chipset'] + chipset)

    # 更新语言切换按钮的文本
    language_button.config(text=LANGUAGES[current_language]['language_button'])

language_button = tk.Button(root, text=LANGUAGES[current_language]['language_button'], command=switch_language)
language_button.pack(side=tk.BOTTOM, pady=10)

def update_cpu_usage():
    # 将更新间隔从1秒改为2秒
    cpu_percent = psutil.cpu_percent(interval=2)
    core_percentages = psutil.cpu_percent(percpu=True)
    cpu_label_text.set(LANGUAGES[current_language]['cpu_total_usage'] + f"{cpu_percent}%")
    for i in range(cpu_count):
        core_text_vars[i].set(LANGUAGES[current_language]['cpu_core_usage'] + f"{i} 使用率: {core_percentages[i]}%")
    root.after(2000, update_cpu_usage)  # 将更新间隔改为2秒

def on_closing():
    if messagebox.askokcancel('Close', LANGUAGES[current_language]['close_confirm']):
        root.destroy()

root.protocol("WM_DELETE_WINDOW", on_closing)

# 关闭启动动画窗口
splash.destroy()

# 启动 CPU 使用率更新
update_cpu_usage()

def on_resize(event):
    # 获取当前窗口宽度
    window_width = root.winfo_width()
    
    # 设置所有 Label 的 wraplength 为窗口宽度减去 50（留出边距）
    wraplength = window_width - 50
    
    # 更新需要换行的 Label
    cpu_features_label.config(wraplength=wraplength)
    network_label.config(wraplength=wraplength)
    slot_info_label.config(wraplength=wraplength)
    
    # 更新 Notebook 的布局
    notebook.pack(fill=tk.BOTH, expand=True)
    
    # 更新每个选项卡中的内容布局
    for tab in [system_tab, cpu_tab, memory_disk_tab, network_tab, motherboard_tab]:
        for child in tab.winfo_children():
            if isinstance(child, tk.Label):
                child.grid(sticky=tk.W, padx=10, pady=5)

# 绑定窗口大小改变事件
root.bind('<Configure>', on_resize)

# 在内存和硬盘信息获取处添加缓存机制
memory_info_cache = None
disk_info_cache = None
last_update_time = 0

def get_memory_info():
    global memory_info_cache, last_update_time
    current_time = time.time()
    if memory_info_cache is None or current_time - last_update_time > 5:  # 5秒缓存
        memory = psutil.virtual_memory()
        memory_info_cache = {
            'total': memory.total / (1024 ** 3),
            'used': memory.used / (1024 ** 3),
            'available': memory.available / (1024 ** 3),
            'percent': memory.percent
        }
        last_update_time = current_time
    return memory_info_cache

def get_disk_info():
    global disk_info_cache, last_update_time
    current_time = time.time()
    if disk_info_cache is None or current_time - last_update_time > 5:  # 5秒缓存
        disk = psutil.disk_usage('/')
        disk_info_cache = {
            'total': disk.total / (1024 ** 3),
            'used': disk.used / (1024 ** 3),
            'free': disk.free / (1024 ** 3),
            'percent': disk.percent
        }
        last_update_time = current_time
    return disk_info_cache

# 修改内存和硬盘信息显示部分
def update_memory_disk_info():
    memory_info = get_memory_info()
    disk_info = get_disk_info()
    
    memory_label.config(text=LANGUAGES[current_language]['memory'] + '≈' + str(round(memory_info['total'], 2)) + 'G')
    memory_used.config(text=f"{LANGUAGES[current_language]['memory']}已用: {round(memory_info['used'], 2)}G")
    memory_available.config(text=f"{LANGUAGES[current_language]['memory']}可用: {round(memory_info['available'], 2)}G")
    memory_percent.config(text=f"{LANGUAGES[current_language]['memory']}使用率: {memory_info['percent']}%")
    
    disk_label.config(text=LANGUAGES[current_language]['disk'] + '≈' + str(round(disk_info['total'], 2)) + 'G')
    disk_used.config(text=f"{LANGUAGES[current_language]['disk']}已用: {round(disk_info['used'], 2)}G")
    disk_free.config(text=f"{LANGUAGES[current_language]['disk']}可用: {round(disk_info['free'], 2)}G")
    disk_percent.config(text=f"{LANGUAGES[current_language]['disk']}使用率: {disk_info['percent']}%")
    
    root.after(5000, update_memory_disk_info)  # 每5秒更新一次

# 在程序启动时调用
update_memory_disk_info()

root.mainloop()
